import React, { Component } from 'react'

export default class NotFound extends Component {
  render() {
    return (
      <div>Page is not found</div>
    )
  }
}
